﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _3.ShoppingSpree
{
    class StartUp
    {
        static void Main(string[] args)
        {
            List<Person> persons = new List<Person>();
            List<Product> products = new List<Product>();
            try
            {
                string[] arrayPersons = Console.ReadLine()
                  .Split(";", StringSplitOptions.RemoveEmptyEntries);

                foreach (var item in arrayPersons)
                {
                    string[] itemParts = item.Split("=");
                    Person person = new Person(itemParts[0], int.Parse(itemParts[1]));
                    persons.Add(person);
                }

                string[] arrayProducts = Console.ReadLine()
                   .Split(";", StringSplitOptions.RemoveEmptyEntries);

                foreach (var item in arrayProducts)
                {
                    string[] itemParts = item.Split("=");
                    Product product = new Product(itemParts[0], int.Parse(itemParts[1]));
                    products.Add(product);
                }

                while (true)
                {
                    string command = Console.ReadLine();
                    if (command == "END")
                        break;

                    string[] purchase = command.Split();
                    string personName = purchase[0];
                    string productName = purchase[1];

                    Person person = persons.FirstOrDefault(x => x.Name == personName);
                    Product product = products.FirstOrDefault(x => x.Name == productName);

                    if (person.Money >= product.Cost)
                    {
                        person.bag.Add(product);
                        person.Money -= product.Cost;
                        Console.WriteLine($"{person.Name} bought {product.Name}");
                    }
                    else
                    {
                        Console.WriteLine($"{person.Name} can't afford {product.Name}");
                    }
                }

                foreach (var item in persons)
                {
                    var productNames = item.bag.Select(x => x.Name).ToList();

                    if (productNames.Count > 0)
                        Console.WriteLine($"{item.Name} - {string.Join(", ", productNames)}");
                    else
                        Console.WriteLine($"{item.Name} - Nothing bought");
                }
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
    }
}

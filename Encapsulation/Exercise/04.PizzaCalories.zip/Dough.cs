﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _4.PizzaCalories
{
    public class Dough
    {
        private const int minWeight = 1;
        private const int maxWeight = 200;
        private const double baseGramCalories = 2.00;

        private string flourType;
        private string bakingTechnique;
        private int weight;

        public Dough(string flourType, string bakingTechnique, int weight)
        {
            this.FlourType = flourType;
            this.BakingTechnique = bakingTechnique;
            this.Weight = weight;
        }

        private string FlourType
        {
            get => this.flourType;
            set
            {
                var valueLower = value.ToLower();
                if (valueLower != "white" && valueLower != "wholegrain")
                {
                    throw new ArgumentException("Invalid type of dough.");
                }

                this.flourType = value;
            }
        }

        private string BakingTechnique
        {
            get => this.bakingTechnique;
            set
            {
                var bakingLower = value.ToLower();

                if (bakingLower != "crispy" && bakingLower != "chewy" &&
                    bakingLower != "homemade")
                {
                    throw new ArgumentException("Invalid type of dough.");
                }

                this.bakingTechnique = value;
            }
        }

        private int Weight
        {
            get => this.weight;

            set
            {
                if (value < minWeight || value > maxWeight)
                {
                    throw new ArgumentException($"Dough weight should be " +
                        $"in the range [{minWeight}..{maxWeight}].");
                }

                this.weight = value;
            }
        }

        public double Calories
        {
            get
            {
                double flourTypeModifier = GetFlourTypeModifier();
                double bakingTechnigueModifier = GetBakingTechnigueModifier();

                double totalCalories = Weight * baseGramCalories * flourTypeModifier *
                    bakingTechnigueModifier;

                return totalCalories;
            }
        }

        private double GetBakingTechnigueModifier()
        {
            string bakingTechniqueLower = this.BakingTechnique.ToLower();

            if (bakingTechniqueLower == "crispy")
            {
                return 0.9;
            }
            else if (bakingTechniqueLower == "chewy")
            {
                return 1.1;
            }

            return 1.0;
        }

        private double GetFlourTypeModifier()
        {
            string flourTypeLower = this.FlourType.ToLower();

            if (flourTypeLower == "white")
            {
                return 1.5;
            }

            return 1.0;
        }
    }
}

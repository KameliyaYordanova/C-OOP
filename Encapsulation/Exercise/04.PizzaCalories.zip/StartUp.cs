﻿using System;

namespace _4.PizzaCalories
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            string pizzaName = Console.ReadLine().Split()[1];

            var doughData = Console.ReadLine().Split(' ', StringSplitOptions.RemoveEmptyEntries);
            string flourType = doughData[1];
            string bakingTechnique = doughData[2];
            int weight = int.Parse(doughData[3]);

            try
            {
                Dough dough = new Dough(flourType, bakingTechnique, weight);
                Pizza pizza = new Pizza(pizzaName);
                pizza.Dough = dough;

                while (true)
                {
                    string line = Console.ReadLine();

                    if (line == "END")
                        break;

                    string[] toppingData = line.Split(' ', StringSplitOptions.RemoveEmptyEntries);
                    string toppingName = toppingData[1];
                    int weightTopping = int.Parse(toppingData[2]);

                    var topping = new Topping(toppingName, weightTopping);

                    pizza.AddTopping(topping);
                }

                Console.WriteLine($"{pizza.Name} - {pizza.Calories:F2} Calories.");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}

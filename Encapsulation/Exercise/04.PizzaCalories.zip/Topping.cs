﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _4.PizzaCalories
{
    public class Topping
    {
        private const int minWeight = 1;
        private const int maxWeight = 50;
        private const double baseGramCalories = 2.00;

        private string name;
        private int weight;

        public Topping(string name, int weight)
        {
            this.Name = name;
            this.Weight = weight;
        }

        private string Name
        {
            get => this.name;

            set
            {
                var valueLower = value.ToLower();
                if (valueLower != "meat" && valueLower != "veggies" &&
                   valueLower != "cheese" && valueLower != "sauce")
                {
                    throw new ArgumentException($"Cannot place {value} " +
                        "on top of your pizza.");
                }

                this.name = value;
            }
        }

        private int Weight
        {
            get => this.weight;

            set
            {
                if (value < minWeight || value > maxWeight)
                {
                    throw new ArgumentException($"{this.Name} weight " +
                        $"should be in the range [{minWeight}..{maxWeight}].");
                }

                this.weight = value;
            }
        }

        public double Calories
        {
            get
            {
                double modifier = GetModifier();
                double totalCaloriesToping = this.Weight * baseGramCalories * modifier;

                return totalCaloriesToping;
            }
        }

        private double GetModifier()
        {
            string nameLower = this.Name.ToLower();
            if (nameLower == "meat")
            {
                return 1.2;
            }
            else if (nameLower == "veggies")
            {
                return 0.8;
            }
            else if (nameLower == "cheese")
            {
                return 1.1;
            }

            return 0.9;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace FootballTeamGenerator
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            List<Team> teams = new List<Team>();

            while (true)
            {
                string input = Console.ReadLine();
                if (input.Equals("END"))
                    break;

                try
                {
                    string[] data = input.Split(";");
                    string teamName = data[1];

                    if (data[0] == "Team")
                    {
                        Team team = new Team(teamName);
                        teams.Add(team);
                    }
                    else if (data[0] == "Add")
                    {
                        Team team = teams.FirstOrDefault(t => t.Name == teamName);

                        if (team == null)
                            throw new ArgumentException($"Team {teamName} does not exist.");

                        string playerName = data[2];
                        int endurance = int.Parse(data[3]);
                        int sprint = int.Parse(data[4]);
                        int dribble = int.Parse(data[5]);
                        int passing = int.Parse(data[6]);
                        int shooting = int.Parse(data[7]);

                        Player player = new Player(playerName, endurance,
                            sprint, dribble, passing, shooting);

                        team.AddPlayer(player);
                    }
                    else if (data[0] == "Remove")
                    {
                        Team team = teams.FirstOrDefault(x => x.Name == teamName);

                        if (team == null)
                            throw new ArgumentException($"Team {teamName} does not exist.");

                        team.RemovePlayer(data[2]);
                    }
                    else if (data[0] == "Rating")
                    {
                        var team = teams.FirstOrDefault(t => t.Name == teamName);

                        if (team == null)
                            throw new ArgumentException($"Team {teamName} does not exist.");
                        else
                            Console.WriteLine($"{team.Name} - {team.Rating}");
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }

            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FootballTeamGenerator
{
    public class Team
    {
        private string name;
        private List<Player> players;

        public Team(string name)
        {
            this.Name = name;
            players = new List<Player>();
        }

        public string Name
        {
            get => this.name;

            private set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentException("A name should not be empty.");
                }
                this.name = value;
            }
        }

        public int Rating
        {
            get
            {
                List<double> averageSkills = players.Select(x => x.AverageSkill).ToList();

                if (averageSkills.Any())
                    return (int)Math.Round(averageSkills.Average());
                else
                    return 0;
            }
        }

        public void AddPlayer(Player player)
        {
            Player currentPlayer = players.FirstOrDefault(p => p.Name == player.Name);

            if (currentPlayer == null)
                players.Add(player);
        }

        public void RemovePlayer(string playerName)
        {
            Player player = players.FirstOrDefault(p => p.Name == playerName);

            if (player != null)
                players.Remove(player);
            else
                throw new ArgumentException($"Player {playerName} is not in {Name} team.");
        }
    }
}

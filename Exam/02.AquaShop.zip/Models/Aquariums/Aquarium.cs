﻿using AquaShop.Models.Aquariums.Contracts;
using AquaShop.Models.Decorations.Contracts;
using AquaShop.Models.Fish.Contracts;
using AquaShop.Utilities.Messages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AquaShop.Models.Aquariums
{
    public abstract class Aquarium : IAquarium
    {
        private string name;
        private List<IDecoration> decorations;
        private List<IFish> fishes;

        protected Aquarium(string name, int capacity)
        {
            Name = name;
            Capacity = capacity;
            fishes = new List<IFish>();
            decorations = new List<IDecoration>();
        }

        public string Name
        {
            get => this.name;

            private set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentException(ExceptionMessages.InvalidAquariumName);
                }
                this.name = value;
            }
        }

        public int Capacity { get; private set; }

        public int Comfort => decorations.Sum(x => x.Comfort); 

        public ICollection<IDecoration> Decorations => this.decorations.AsReadOnly();

        public ICollection<IFish> Fish => this.fishes.AsReadOnly(); 

        public void AddDecoration(IDecoration decoration)
        {
            this.decorations.Add(decoration);
        }

        public void AddFish(IFish fish)
        {
            if (Capacity == this.fishes.Count)
            {
                throw new InvalidOperationException(ExceptionMessages.NotEnoughCapacity);
            }

            this.fishes.Add(fish);
        }

        public void Feed() 
        {
            foreach (var food in fishes)
            {
                food.Eat();
            }
        }

        public string GetInfo()
        {
            return this.ToString();
        }

        public bool RemoveFish(IFish fish)
        {
            return this.fishes.Remove(fish);
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine($"{this.Name} ({this.GetType().Name}):");

            if (this.Fish.Count == 0)
                sb.AppendLine("Fish: none");
            else
                sb.AppendLine($"Fish: {string.Join(", ", this.Fish.Select(x => x.Name).ToArray())}");

            sb.AppendLine($"Decorations: { this.Decorations.Count}");
            sb.AppendLine($"Comfort: { this.Comfort}");

            return sb.ToString();
        }
    }
}

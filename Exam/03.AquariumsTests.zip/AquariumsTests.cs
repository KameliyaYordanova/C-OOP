﻿namespace Aquariums.Tests
{
    using NUnit.Framework;
    using System;

    [TestFixture]
    public class AquariumsTests
    {
        private Fish fishes;
        private Aquarium aquariums;

        [SetUp]
        public void SetUp()
        {
            fishes = new Fish("Geri");
            aquariums = new Aquarium("Styklo", 3);
        }

        //Test Fish
        [Test]
        public void PropNameFish()
        {
            var name = "Geri";
            Assert.AreEqual(name, fishes.Name);
        }

        //Test Aquarium
        [Test]
        public void ConstructorAquarium()
        {
            var name = "Styklo";
            var capacity = 3;
            var count = 0;

            Assert.AreEqual(name, aquariums.Name);
            Assert.AreEqual(capacity, aquariums.Capacity);
            Assert.AreEqual(count, aquariums.Count);
        }

        [Test]
        public void AquariumNameNullOrEmpty_Exception()
        {
            Assert.Throws<ArgumentNullException>(() =>
            aquariums = new Aquarium(null, 3));

            Assert.Throws<ArgumentNullException>(() =>
            aquariums = new Aquarium("", 3));
        }

        [Test]
        public void AquariumCapacity_Exception()
        {
            Assert.Throws<ArgumentException>(() =>
            aquariums = new Aquarium("Styklo", -3));
        }

        [Test]
        public void AquariumAddCapacityIsFull_Exception()
        {
            aquariums = new Aquarium("Styklo", 1);
            aquariums.Add(new Fish("test"));

            Assert.Throws<InvalidOperationException>(() =>
            aquariums.Add(new Fish("Test1")));
        }

        [Test]
        public void AddWorking()
        {
            aquariums.Add(fishes);
            aquariums.Add(new Fish("Pepi"));
            Assert.AreEqual(aquariums.Count, 2);
        }

        [Test]
        public void AquariumRemove_Exception()
        {
            aquariums.Add(fishes);

            Assert.Throws<InvalidOperationException>(() =>
            aquariums.RemoveFish("Nqma takava riba"));
        }

        [Test]
        public void AquariumRemove_Worked()
        {
            aquariums.Add(fishes);
            aquariums.Add(new Fish("Zlatna"));

            Assert.AreEqual(aquariums.Count, 2);

            aquariums.RemoveFish("Zlatna");
            Assert.AreEqual(aquariums.Count, 1);
        }

        [Test]
        public void AquariumSellFishWorked()
        {
            //aquariums.Add(fishes);
            aquariums.Add(new Fish("Dido"));
            var fish = aquariums.SellFish("Dido");

            Assert.AreEqual(fish.Available, false);
        }

        [Test]
        public void AquariumSell_Exception()
        {
            aquariums.Add(fishes);

            Assert.Throws<InvalidOperationException>(() =>
            aquariums.SellFish("Nqma takava riba"));
        }

        [Test]
        public void RepotWorked()
        {
            //aquariums.Add(fishes);
            aquariums.Add(new Fish("Jeni"));
            var expectedResult = $"Fish available at {aquariums.Name}: Jeni";

            var result = aquariums.Report();
            Assert.AreEqual(result, expectedResult);
        }
    }
}

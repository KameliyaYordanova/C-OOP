﻿namespace PlayersAndMonsters
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            BladeKnight dwarf = new BladeKnight("Pinokio", 10);
            BladeKnight dwarf2 = new BladeKnight("Harry Potter", 10);

            System.Console.WriteLine(dwarf);
            System.Console.WriteLine(dwarf2);
        }
    }
}
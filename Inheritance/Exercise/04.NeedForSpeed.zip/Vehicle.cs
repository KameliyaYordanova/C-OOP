﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NeedForSpeed
{
    public class Vehicle
    {
        public const double DefaultFuelConsumtpion = 1.25;

        public Vehicle(int horsePower, double fuel)
        {
            this.HorsePower = horsePower;
            this.Fuel = fuel;
        }

        public int HorsePower { get; set; }

        public double Fuel { get; set; }

        public virtual double FuelConsumption => DefaultFuelConsumtpion;

        public void Drive(double kilometers)
        {
            double totalKm = this.Fuel - this.FuelConsumption * kilometers;
            if (totalKm >= 0)
                this.Fuel = totalKm;
        }
    }
}

﻿using System;

namespace Farm
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Dog Sharo = new Dog();
            Sharo.Eat();
            Sharo.Bark();
        }
    }
}

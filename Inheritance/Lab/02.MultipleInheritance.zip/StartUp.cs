﻿using System;

namespace Farm
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Puppy doggi = new Puppy();
            doggi.Eat();
            doggi.Bark();
            doggi.Weep();
        }
    }
}

﻿using System;

namespace Farm
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Dog Brezko = new Dog();
            Brezko.Eat();
            Brezko.Bark();

            Cat Prokopi = new Cat();
            Prokopi.Eat();
            Prokopi.Meow();
        }
    }
}

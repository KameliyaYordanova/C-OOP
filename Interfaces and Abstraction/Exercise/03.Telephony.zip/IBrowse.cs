﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _3.Telephony
{
    public interface IBrowse
    {
        string Browse(string url);
    }
}

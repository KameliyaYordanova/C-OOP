﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _3.Telephony
{
    public interface ICall
    {
        string Calling(string number);
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _3.Telephony
{
    public class Smartphone : ICall, IBrowse
    {
        public string Browse(string url)
        {
            if (url.Any(Char.IsDigit))
            {
                return "Invalid URL!";
            }

            return $"Browsing: {url}!";
        }

        public string Calling(string number)
        {
            return $"Calling... {number}";
        }
    }
}

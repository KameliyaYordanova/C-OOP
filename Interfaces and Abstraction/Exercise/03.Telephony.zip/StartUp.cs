﻿using System;
using System.Linq;

namespace _3.Telephony
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            string[] numbers = Console.ReadLine().Split();
            string[] url = Console.ReadLine().Split();

            Smartphone smartphone = new Smartphone();
            StationaryPhone stationary = new StationaryPhone();


            foreach (var number in numbers)
            {
                if (number.Any(Char.IsLetter))
                {
                    Console.WriteLine("Invalid number!");
                }
                else
                {
                    if (number.Length == 10)
                        Console.WriteLine(smartphone.Calling(number));
                    else if(number.Length == 7)
                        Console.WriteLine(stationary.Calling(number));
                }
            }

            foreach (var site in url)
            {
                Console.WriteLine(smartphone.Browse(site));
            }
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _04.BorderControl
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            string input = string.Empty;
            List<IId> idList = new List<IId>();

            while ((input = Console.ReadLine()) != "End")
            {
                var data = input.Split();
                var nameModel = data[0];

                if (data.Length == 3)
                {
                    var age = int.Parse(data[1]);
                    var id = data[2];

                    IId cictizen = new Citizens(nameModel, age, id);
                    idList.Add(cictizen);
                }
                else
                {
                    var id = data[1];
                    IId robot = new Robots(nameModel, id);
                    idList.Add(robot);
                }
            }

            string lastId = Console.ReadLine();
            idList = idList.Where(x => x.Id.EndsWith(lastId)).ToList();
            idList.ForEach(Console.WriteLine);
        }
    }
}

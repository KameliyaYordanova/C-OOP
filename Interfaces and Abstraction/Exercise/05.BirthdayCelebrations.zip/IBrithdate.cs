﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _5.BirthdayCelebrations
{
    public interface IBrithdate
    {
        public string Name { get; set; }

        public string Birthdate { get; set; }
    }
}

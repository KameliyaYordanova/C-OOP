﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _5.BirthdayCelebrations
{
    public interface IId
    {
        public string Id { get; set; }
    }
}

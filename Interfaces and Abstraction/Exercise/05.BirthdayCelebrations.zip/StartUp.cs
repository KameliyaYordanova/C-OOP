﻿using _04.BorderControl;
using System;
using System.Collections.Generic;
using System.Linq;

namespace _5.BirthdayCelebrations
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            List<IBrithdate> listOfBirthday = new List<IBrithdate>();
            string input = string.Empty;

            while ((input = Console.ReadLine()) != "End")
            {
                var data = input.Split();
                var type = data[0];
                var nameOrModel = data[1];

                if (type == "Citizen")
                {
                    var name = data[1];
                    var age = int.Parse(data[2]);
                    var id = data[3];
                    var birthday = data[4];

                    IBrithdate citizen = new Citizens(name, age, id, birthday);
                    listOfBirthday.Add(citizen);
                }
                else if (type == "Pet")
                {
                    var name = data[1];
                    var birthdate = data[2];

                    IBrithdate pet = new Pet(name, birthdate);
                    listOfBirthday.Add(pet);
                }
            }
            string year = Console.ReadLine();
            listOfBirthday = listOfBirthday.Where(x => x.Birthdate.EndsWith(year)).ToList();
            listOfBirthday.ForEach(Console.WriteLine);
        }
       
    }
}

﻿using _04.BorderControl;
using System;
using System.Collections.Generic;

namespace _6.FoodShortage
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            List<IBuyer> listofPerson = new List<IBuyer>();

            for (int i = 1; i <= n; i++)
            {
                string[] data = Console.ReadLine()
                    .Split();
                string name = data[0];
                int age = int.Parse(data[1]);

                if (data.Length == 4)
                {
                    string id = data[2];
                    string birthDate = data[3];
                    IBuyer citizen = new Citizens(name, age, id, birthDate);
                    listofPerson.Add(citizen);
                }
                else if(data.Length == 3)
                {
                    string group = data[2];
                    IBuyer rabel = new Rebel(name, age, group);
                    listofPerson.Add(rabel);
                }
            }

            while (true)
            {
                string command = Console.ReadLine();
                if (command == "End")
                {
                    break;
                }

                foreach (var person in listofPerson)
                {
                    if (person.Name == command )
                    {
                        person.BuyFood();
                    }
                }
            }

            int total = 0;
            foreach (var person in listofPerson)
            {
                total += person.Food;
            }

            Console.WriteLine(total);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _7.MilitaryElite.Contracts.Enums
{
    public enum  MissionsState
    {
        inProgress,
        Finished
    }
}

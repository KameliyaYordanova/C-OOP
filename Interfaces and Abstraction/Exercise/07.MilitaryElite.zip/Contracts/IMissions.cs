﻿using _7.MilitaryElite.Contracts.Enums;

namespace _7.MilitaryElite.Contracts
{
    public interface IMissions
    {
        string CodeName { get; }

        MissionsState MissionsState { get; }

        void CompleteMission();
    }
}

﻿using _7.MilitaryElite.Contracts;
using _7.MilitaryElite.Contracts.Enums;
using System;
using System.Collections.Generic;
using System.Text;

namespace _7.MilitaryElite.Models
{
    public class Commando : SpecialisedSoldier, ICommando
    {
        private List<IMissions> mission;
        
        public Commando(string id, string firstName, string lastName, decimal salary, 
            Corps corps) 
            : base(id, firstName, lastName, salary, corps)
        {
            mission = new List<IMissions>();
        }

        public IReadOnlyCollection<IMissions> Missions => this.mission.AsReadOnly();

        public void AddMission(IMissions missions)
        {
           this.mission.Add(missions);
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(base.ToString());

            sb.AppendLine("Missions:");
            foreach (var mission in this.Missions)
            {
                sb.AppendLine($"  {mission}");
            }

            return sb.ToString().TrimEnd();
        }
    }
}

﻿using _7.MilitaryElite.Contracts;
using _7.MilitaryElite.Contracts.Enums;
using System;
using System.Collections.Generic;
using System.Text;

namespace _7.MilitaryElite.Models
{
    public class Engineer : SpecialisedSoldier, IEngineer
    {
        private List<IRepairs> repairs;

        public Engineer(string id, string firstName, string lastName, decimal salary, 
            Corps corps)
            : base(id, firstName, lastName, salary, corps)
        {
            repairs = new List<IRepairs>();
        }

        public IReadOnlyCollection<IRepairs> Repairs => repairs.AsReadOnly();

        public void AddRepair(IRepairs repair)
        {
            repairs.Add(repair);
        }
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(base.ToString());

            sb.AppendLine("Repairs:");
            foreach (var repair in this.Repairs)
            {
                sb.AppendLine($"  {repair}");
            }

            return sb.ToString().TrimEnd();
        }
    }
}

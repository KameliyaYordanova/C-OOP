﻿using _7.MilitaryElite.Contracts;
using _7.MilitaryElite.Contracts.Enums;
using System;
using System.Collections.Generic;
using System.Text;

namespace _7.MilitaryElite.Models
{
    public class Mission : IMissions
    {
        public Mission(string codeName, MissionsState missionsState)
        {
            CodeName = codeName;
            MissionsState = missionsState;
        }

        public string CodeName { get; private set; }

        public MissionsState MissionsState { get; private set; }

        public void CompleteMission()
        {
            MissionsState = MissionsState.Finished;
        }

        public override string ToString()
        {
            return $"Code Name: {CodeName} State: {MissionsState}";
        }

    }
}

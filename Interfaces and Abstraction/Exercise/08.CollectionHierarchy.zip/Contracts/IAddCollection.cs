﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _8.CollectionHierarchy.Contracts
{
    public interface IAddCollection
    {
        public int Add(string element);
    }
}

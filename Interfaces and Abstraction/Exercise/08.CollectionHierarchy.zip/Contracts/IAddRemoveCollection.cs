﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _8.CollectionHierarchy.Contracts
{
    public interface IAddRemoveCollection : IAddCollection
    {
        public string Remove();
    }
}

﻿using _09.ExplicitInterfaces.Contracts;
using System;

namespace _09.ExplicitInterfaces
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            while (true)
            {
                string input = Console.ReadLine();
                if (input == "End")
                    break;

                string[] data = input.Split();
                string name = data[0];
                string country = data[1];
                int age = int.Parse(data[2]);

                Citizen citizen = new Citizen(name, country, age);

                Console.WriteLine(((IPerson)citizen).GetName());
                Console.WriteLine(((IResident)citizen).GetName());
            }
        }
    }
}

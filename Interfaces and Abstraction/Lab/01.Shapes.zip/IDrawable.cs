﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AbstractionLab
{
    public interface IDrawable
    {
        void Draw();
    }
}

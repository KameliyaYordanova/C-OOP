﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _1.Vehicles
{
    public class Car : Veliche
    {
        private const double additionalConsumptionPerKm = 0.9;

        public Car(double fuelQuantity, double fuelConsumption) 
            : base(fuelQuantity, fuelConsumption)
        {
        }

        protected override double AdditionalConsumption => additionalConsumptionPerKm;
    }
}

﻿using System;

namespace _1.Vehicles
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            string[] inputCar = Console.ReadLine().Split(' ', StringSplitOptions.RemoveEmptyEntries);
            double fuelCuantityCar = double.Parse(inputCar[1]);
            double fuelConsumptionCar = double.Parse(inputCar[2]);

            Veliche car = new Car(fuelCuantityCar, fuelConsumptionCar);

            string[] inputTruck = Console.ReadLine().Split(' ', StringSplitOptions.RemoveEmptyEntries);
            double fuelCuantityTruck = double.Parse(inputTruck[1]);
            double fuelConsumptionTruck = double.Parse(inputTruck[2]);

            Veliche truck = new Truck(fuelCuantityTruck, fuelConsumptionTruck);

            int count = int.Parse(Console.ReadLine());

            for (int i = 0; i < count; i++)
            {
               string[] input = Console.ReadLine().Split(' ', StringSplitOptions.RemoveEmptyEntries);

                string type = input[1];
                string command = input[0];
                double value = double.Parse(input[2]);

                switch (type)
                {
                    case nameof(Car):
                        ExecuteCommand(car, command, value);
                        break;
                    case nameof(Truck):
                        ExecuteCommand(truck, command, value);
                        break;
                }
            }

            Console.WriteLine(car);
            Console.WriteLine(truck);
        }

        private static void ExecuteCommand(Veliche vehicle, string command, double value)
        {
            switch (command)
            {
                case "Drive":
                    Console.WriteLine(vehicle.Drive(value));
                    break;
                case "Refuel":
                    vehicle.Refuel(value);
                    break;
            }

        }
    }
}

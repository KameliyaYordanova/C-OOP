﻿using Vehicles;
using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles
{
    public class Bus : Vehice
    {
        private const double busAirModifier = 1.4; 

        public Bus(double fuel,
            double fuelConsumption,
            double tankCapacity) 
            : base(fuel, fuelConsumption, tankCapacity, busAirModifier)
        {
        }

        public void TurnOnAirCondition()
        {
            this.AirConditionModifier = busAirModifier;
        }

        public void TurnOffAirCondition()
        {
            this.AirConditionModifier = 0;
        }
    }
}

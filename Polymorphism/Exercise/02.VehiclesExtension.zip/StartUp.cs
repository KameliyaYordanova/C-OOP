﻿
using System;
using Vehicles;

namespace Veliches
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            try
            {

                Vehice car = CreateVeliche();
                Vehice truck = CreateVeliche();
                Vehice bus = CreateVeliche();

                int n = int.Parse(Console.ReadLine());

                for (int i = 0; i < n; i++)
                {
                    string[] parts = Console.ReadLine().Split();

                    string command = parts[0];
                    string velicheType = parts[1];
                    double parameter = double.Parse(parts[2]);

                    if (velicheType == nameof(Car))
                    {
                        ProcessCommand(car, command, parameter);
                    }
                    else if (velicheType == nameof(Bus))
                    {
                        ProcessCommand(bus, command, parameter);
                    }
                    else
                    {
                        ProcessCommand(truck, command, parameter);
                    }
                }

                Console.WriteLine(car);
                Console.WriteLine(truck);
                Console.WriteLine(bus);
            }
            catch (Exception ex)
            when (ex is InvalidOperationException || ex is ArgumentException)
            {
                Console.WriteLine(ex.Message);
            }

        }

        private static void ProcessCommand(Vehice veliche, string command, double parameter)
        {
            try
            {
                if (command == "Drive")
                {
                    veliche.Drive(parameter);
                    Console.WriteLine($"{veliche.GetType().Name} travelled {parameter} km");

                }
                else if (command == "DriveEmpty")
                {
                    ((Bus)veliche).TurnOffAirCondition();
                    veliche.Drive(parameter);

                    Console.WriteLine($"{veliche.GetType().Name} travelled {parameter} km");
                    ((Bus)veliche).TurnOnAirCondition();
                }
                else
                {
                    veliche.Refuel(parameter);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        private static Vehice CreateVeliche()
        {
            string[] parts = Console.ReadLine().Split();

            string type = parts[0];
            double fuelQuatity = double.Parse(parts[1]);
            double fuelConsumptio = double.Parse(parts[2]);
            double tankCapacity = double.Parse(parts[3]);

            Vehice veliche = null;

            if (type == nameof(Car))
            {
                veliche = new Car(fuelQuatity, fuelConsumptio, tankCapacity);
            }
            else if (type == nameof(Truck))
            {
                veliche = new Truck(fuelQuatity, fuelConsumptio, tankCapacity);
            }
            else if (type == nameof(Bus))
            {
                veliche = new Bus(fuelQuatity, fuelConsumptio, tankCapacity);
            }

            return veliche;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles
{
    public abstract class Vehice
    {
        private double fuel;

        protected Vehice(double fuel, double fuelConsumption, double tankCapacity,
            double airConditionModifier)
        {
            TankCapacity = tankCapacity;
            Fuel = fuel;
            FuelConsumption = fuelConsumption;
            AirConditionModifier = airConditionModifier;
        }
        protected double AirConditionModifier { get; set; }

        public double Fuel
        {
            get => this.fuel;
            protected set
            {
                if (value > TankCapacity)
                {
                    fuel = 0;
                }
                else
                {
                    fuel = value; 
                }
            }
        }

        private double FuelConsumption { get; set; }

        public double TankCapacity { get; set; }

        public void Drive(double distance)
        {
            double requerdFuel = (FuelConsumption + AirConditionModifier) * distance;

            if (requerdFuel > Fuel)
            {
                throw new InvalidOperationException($"{this.GetType().Name} needs refueling");
            }

            this.Fuel -= requerdFuel;
        }

        public virtual void Refuel(double amount)
        {
            if (amount <= 0)
            {
                throw new ArgumentException("Fuel must be a positive number");
            }

            if (Fuel + amount > this.TankCapacity)
            {
                throw new InvalidOperationException($"Cannot fit {amount} fuel in the tank");
            }
            this.Fuel += amount;
        }

        public override string ToString()
        {
            return $"{this.GetType().Name}: {this.Fuel:f2}";
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _3.Raiding
{
    public class Druid : BaseHero
    {
        private const int druidfPower = 80;

        public Druid(string name) 
            : base(name, druidfPower)
        {
        }

        public override string CastAbility()
        {
            return $"{nameof(Druid)} - {Name} healed for {Power}";
        }
    }
}

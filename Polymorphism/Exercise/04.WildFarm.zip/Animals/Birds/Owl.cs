﻿
using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm
{
    public class Owl : Bird
    {
        private const double baseWeightModifire = 0.25;
        private static HashSet<string> owlAllFoods = new HashSet<string>
        {
            nameof(Meat)
        };

        public Owl(string name,
            double weight,
            double wingSize) 
            : base(name, weight, owlAllFoods, baseWeightModifire, wingSize)
        {
        }

        public override string ProduceSound()
        {
            return "Hoot Hoot";
        }
    }
}

﻿
using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm
{
   public class Tiger : Feline
    {
        private const double baseWeightModifire = 1.00;
        private static HashSet<string> tigerAllFoods = new HashSet<string>
        {
            nameof(Meat),
        };
        public Tiger(string name,
            double weight,
            string livingRegion,
            string breed)
            : base(name, weight, tigerAllFoods, baseWeightModifire, livingRegion, breed)
        {
        }

        public override string ProduceSound()
        {
            return "ROAR!!!";
        }
    }
}

﻿
using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm
{
    public class Mouse : Mammal
    {
        private const double baseWeightModifire = 0.10;
        private static HashSet<string> mouseAllFoods = new HashSet<string>
        {
            nameof(Fruit),
            nameof(Vegetable)
        };
        public Mouse(string name,
            double weight,
            string livingRegion) 
            : base(name, weight, mouseAllFoods, baseWeightModifire, livingRegion)
        {
        }

        public override string ProduceSound()
        {
            return "Squeak";
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Shapes
{
    public class Rectangle : Shape
    {
        private const double perimetur = 2.00;
        private double height;
        private double width;

        public Rectangle(double height, double width)
        {
            this.height = height;
            this.width = width;
        }

        public override double CalculateArea()
        {
            return this.width * this.height;
        }

        public override double CalculatePerimeter()
        {
            return (this.width + this.height) * perimetur;
        }

        public override string Draw()
        {
            return $"{base.Draw()} {this.GetType().Name}";
        }
        
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ValidationAttributes.Attributes
{
    public class MyRangeAttribute : MyValidationAttribute
    {
        private int minValue;
        private int maxValue;

        public MyRangeAttribute(int minValue, int maxValue)
        {
            this.Validate(minValue, maxValue);
            this.minValue = minValue;
            this.maxValue = maxValue;
        }
        public override bool IsValid(object obj)
        {
            if (obj is int)
            {
                int value = (int)obj;
                if (value < this.minValue || value > this.maxValue)
                {
                    return false;
                }
                return true;
            }
            else
            {
                throw new InvalidOperationException("invalid type");
            }
        }

        private void Validate(int minValue, int maxValue)
        {
            if (minValue > maxValue)
            {
                throw new ArgumentException("Invalid Range");
            }
        }
    }
}

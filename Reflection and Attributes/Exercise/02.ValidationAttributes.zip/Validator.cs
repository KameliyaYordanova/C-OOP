﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using ValidationAttributes.Attributes;
using System.Reflection;

namespace ValidationAttributes
{
    public static class Validator
    {
        public static bool IsValid(object obj)
        {
            if (obj == null)
                return false;

            Type objectType = obj.GetType();
            var propertis = objectType.GetProperties();

            foreach (var item in propertis)
            {
                MyValidationAttribute[] attributes = item.GetCustomAttributes()
                   .Where(a => a is MyValidationAttribute)
                   .Cast<MyValidationAttribute>()
                   .ToArray();

                foreach (var atribute in attributes)
                {
                    if (!atribute.IsValid(item.GetValue(obj)))
                    {
                        return false;
                    }
                }
            }

            return true;
        }
    }
}

﻿using System;

namespace AuthorProblem
{
    [AuthorAttribute("Venci")]
    public class StartUp
    {
        [AuthorAttribute("Gosho")]
        static void Main(string[] args)
        {

        }
    }
}

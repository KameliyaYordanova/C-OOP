﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;
using System.Linq;

namespace AuthorProblem
{
    public class Tracker
    {
        public void PrintMethodsByAuthor(string author)
        {
          var types = Assembly.GetExecutingAssembly().GetTypes();
            foreach (var type in types)
            {
                var methods = type.GetMethods(BindingFlags.Public | BindingFlags.Instance |
                    BindingFlags.Static | BindingFlags.NonPublic);

                foreach (var method in methods)
                {
                  var attribute = method.GetCustomAttributes<AuthorAttribute>();

                    if (attribute.Any(x => x.Name == author))
                    {
                        Console.WriteLine(method);
                    }
                }
            }
        }
    }
}

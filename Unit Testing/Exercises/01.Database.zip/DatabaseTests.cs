using NUnit.Framework;
using System.Linq;
using System;

    public class DatabaseTests
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void ConstructorShouldBeInitializedWith16Elements()
        {
            int[] numbers = Enumerable.Range(1, 16).ToArray();
            Database database = new Database(numbers);

            int expectedResult = 16;
            int actualResult = database.Count;

            Assert.AreEqual(expectedResult, actualResult);
        }

        [Test]
        public void ConstructorShouldThrowExceptionAreNot16Elements()
        {
            int[] numbers = Enumerable.Range(1, 10).ToArray();
            Database database = new Database(numbers);

            int expectedResult = 10;
            int actualResult = database.Count;

            Assert.AreEqual(expectedResult, actualResult);
        }

        [Test]
        public void AddOperationShouldAddElementAtNextFreeCall()
        {
            // Arrage
            int[] numbers = Enumerable.Range(1, 10).ToArray();
            Database database = new Database(numbers);

            // Act
            database.Add(5);
            var allElements = database.Fetch();

            //Assert
            int expectedResult = 5;
            int actualResult = allElements[10];

            int expectedCount = 11;
            int actualCount = database.Count;

            Assert.AreEqual(expectedResult, actualResult);
            Assert.AreEqual(expectedCount, actualCount);
        }

        [Test]
        public void AddOperationShouldThrowExceptionIfElementsAreAbove16()
        {
            // Arrage
            int[] numbers = Enumerable.Range(1, 16).ToArray();
            Database database = new Database(numbers);

            //Act Assert
            Assert.Throws<InvalidOperationException>(() => database.Add(10));
        }

        [Test]
        public void RemoveOperationLastIndex()
        {
            // Arrage
            int[] numbers = Enumerable.Range(1, 10).ToArray();
            Database database = new Database(numbers);

            //Act
            database.Remove();

            //Assert
            int expectedResult = 9;
            int actualvalue = database.Fetch()[8];

            int expectedCount = 9;
            int actualCount = database.Count;

            Assert.AreEqual(expectedResult, actualvalue);
            Assert.AreEqual(expectedCount, actualCount);
        }

        [Test]
        public void RemoveOperationExceptionDatabaseIsEmpty()
        {
            // Arrage
            Database database = new Database();

            //Act Assert
            Assert.Throws<InvalidOperationException>(() => database.Remove());
        }

        [Test]
        public void FetchSgouldReturnOldElements()
        {
            // Arrage
            int[] numbers = Enumerable.Range(1, 5).ToArray();
            Database database = new Database(numbers);

            //Act
            int[] allItems = database.Fetch();

            //Assert
            int[] expectedValue = { 1, 2, 3, 4, 5 };
            CollectionAssert.AreEqual(expectedValue, allItems);
        }
    }

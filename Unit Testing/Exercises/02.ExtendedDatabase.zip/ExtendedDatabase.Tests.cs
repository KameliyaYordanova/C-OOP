using NUnit.Framework;
using System;

namespace Test
{
    public class ExtendedDatabaseTests
    {
        private ExtendedDatabase extendedDatabase;

        [SetUp]
        public void Setup()
        {
            this.extendedDatabase = new ExtendedDatabase();
        }

        [Test]
        public void AddThrowsExceptionWhenCapacityIsExceeded()
        {
            for (int i = 0; i < 16; i++)
            {
                extendedDatabase.Add(new Person(i, $"Username{i}"));
            }
            Assert.Throws<InvalidOperationException>(() => extendedDatabase.Add(new Person(16,
                "InvalidUsername")));
        }

        [Test]
        public void AddThrowsExceptionWhenUsernameIsUsed()
        {
            extendedDatabase.Add(new Person(1, "Kami"));
            Assert.Throws<InvalidOperationException>(() => extendedDatabase.Add(new Person(2,
                "Kami")));
        }

        [Test]
        public void AddThrowsExceptionWhenIdIsUsed()
        {
            long id = 1;
            extendedDatabase.Add(new Person(id, "RandomUser2"));
            Assert.Throws<InvalidOperationException>(() =>
            extendedDatabase.Add(new Person(id, "RandomUser2")));
        }

        [Test]
        public void AddIncreasesCounterWhenUserIsValid()
        {
            extendedDatabase.Add(new Person(1, "Kami"));
            extendedDatabase.Add(new Person(2, "Tedi"));

            int expectedCount = 2;
            Assert.That(extendedDatabase.Count, Is.EqualTo(expectedCount));
        }

        [Test]
        public void RemoveThrowExceptionWhenDatabaseIsEmpty()
        {
            Assert.Throws<InvalidOperationException>(() =>
            extendedDatabase.Remove());
        }

        [Test]
        public void RemoveElementFromDatabase()
        {
            int n = 5;
            for (int i = 0; i < n; i++)
            {
                extendedDatabase.Add(new Person(i, $"Username{i}"));
            }

            extendedDatabase.Remove();
            Assert.That(extendedDatabase.Count, Is.EqualTo(n - 1));
            Assert.Throws<InvalidOperationException>(() =>
            extendedDatabase.FindById(n - 1));
        }

        [Test]
        [TestCase("")]
        [TestCase(null)]
        public void FindByUsernameThrowsExceptionWhenArgumentIsNotValid(string username)
        {
            Assert.Throws<ArgumentNullException>(() =>
            extendedDatabase.FindByUsername(username));
        }

        [Test]
        public void FindByUsernameThrowsExceptionWhenUsernameDoesNotExist()
        {
            Assert.Throws<InvalidOperationException>(() =>
            extendedDatabase.FindByUsername("Username"));
        }

        [Test]
        public void FindByUsernameReturnsExpectedUserWhenUserExist()
        {
            string username = "Kami";
            Person person = new Person(1, username);

            extendedDatabase.Add(person);

            Person dbperson = extendedDatabase.FindByUsername(person.UserName);

            Assert.That(person, Is.EqualTo(dbperson));
        }

        [Test]
        [TestCase(-1)]
        [TestCase(-25)]
        public void FindByIdThrowsExceptionWhenIdIsLessThanZero(long id)
        {
            Assert.Throws<ArgumentOutOfRangeException>(() =>
           extendedDatabase.FindById(id));
        }

        [Test]
        public void FindByIdThrowsExceptionWhenUserWithIdDoesNotExit()
        {
            Assert.Throws<InvalidOperationException>(() =>
           extendedDatabase.FindById(100));
        }

        [Test]
        public void FindByIdReturnsExpectedUserWhenUserExists()
        {
            Person person = new Person(1, "Kami");
            extendedDatabase.Add(person);

            Person dpPerson = extendedDatabase.FindById(person.Id);

            Assert.That(person, Is.EqualTo(dpPerson));
        }
        [Test]
        public void CtorThrowsExceptionWhenCapacityIsExceeded()
        {
            Person[] arguments = new Person[17];

            for (int i = 0; i < arguments.Length; i++)
            {
               arguments[i] = new Person(i, $"Username{i}");
            }

            Assert.Throws<ArgumentException>(() => extendedDatabase =
            new ExtendedDatabase(arguments));
        }

        [Test]
        public void CtorAddInitialPeopleToDatabase()
        {
            Person[] arguments = new Person[5];

            for (int i = 0; i < arguments.Length; i++)
            {
                arguments[i] = new Person(i, $"Username{i}");
            }

            extendedDatabase = new ExtendedDatabase(arguments);

            Assert.That(extendedDatabase.Count, Is.EqualTo(arguments.Length));
            foreach (var person in arguments)
            {
                Person dpPerson = extendedDatabase.FindById(person.Id);
                Assert.That(person, Is.EqualTo(dpPerson));
            }
        }
    }
}
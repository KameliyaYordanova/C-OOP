﻿using NUnit.Framework;
using System;
using System.Linq;

namespace Test
{
    public class ArenaTests
    {
        private Arena arena;

        [SetUp]
        public void Setup()
        {
            arena = new Arena();
        }

        [Test]
        public void Ctor_InitializeWarrior()
        {
            Assert.That(arena.Warriors, Is.Not.Null);
        }

        [Test]
        public void Count_IsZero_whenArenaIsEmpty()
        {
            Assert.That(arena.Count, Is.EqualTo(0));
        }

        [Test]
        public void Enroll_ThrowsException_WhenWarriorAlreadyExsit()
        {
            string name = "Warrior";

            arena.Enroll(new Warrior(name, 50, 50));

            Assert.Throws<InvalidOperationException>(() => 
            arena.Enroll(new Warrior(name, 55, 55)));
        }

        [Test]
        public void Enroll_IncreasesArenaCount()
        {
            arena.Enroll(new Warrior("Warrior", 50, 50));

            Assert.That(arena.Count, Is.EqualTo(1)); 
        }

        [Test]
        public void Enroll_AddWarriorToWarriors()
        {
            string name = "Warrior";
            arena.Enroll(new Warrior(name,50, 50));

            Assert.That(arena.Warriors.Any(w => w.Name == name), Is.True);
        }

        [Test]
        public void Fight_ThrowsException_WhenDeffenderDoesNotExist()
        {
            string name = "Attacker";
            arena.Enroll(new Warrior(name, 40, 40));

            Assert.Throws<InvalidOperationException>(() => arena.Fight(name, "Defender"));
        }

        [Test]
        public void Fight_ThrowsException_WhenAttackerDoesNotExist()
        {
            string name = "Defender";
            arena.Enroll(new Warrior(name, 40, 40));

            Assert.Throws<InvalidOperationException>(() => arena.Fight("Attacker", name));
        }

        [Test]
        public void Fight_ThrowsException_WhenBothDoesNotExsit()
        {
             Assert.Throws<InvalidOperationException>(() => arena.Fight("Attacker","Defender"));
        }

        [Test]
        public void Fight_BothWarriorsLoseHealthPointsInFight()
        {
            int initialHp = 100;

            Warrior attacker = new Warrior("Attacker", 50, initialHp);
            Warrior defender = new Warrior("Defender", 50, initialHp);

            arena.Enroll(attacker);
            arena.Enroll(defender);

            arena.Fight(attacker.Name, defender.Name);

            Assert.That(attacker.HP, Is.EqualTo(initialHp - defender.Damage));
            Assert.That(defender.HP, Is.EqualTo(initialHp - attacker.Damage));
        }
    }
}
